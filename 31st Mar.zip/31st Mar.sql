--F5 : to run  the command 
create database my_session   --create new db

--change database
use my_session				


CREATE TABLE Customer
(
cid		int identity(1,1),
cname	varchar(100),
email	varchar,			--default size is 1
gender	char(1),			
phone	bigint,
dob		date,
status	bit	
)


--show table details/data
select * from customer 

--show table description 
sp_help customer 

--alter table
alter table Customer  
alter column email varchar(50)  --column column size 


--save data 
insert into customer
values('raman','raman@gmail.com','m',9876657899,'1990-11-30',1)


select * from customer 

--update  data 
update customer
set cname ='Jatin' , status =0 
where cid = 3


--delete row
delete from customer --delete all 

delete from customer where cid = 30 --delete selected 


---
create table product
(
pid			int identity(1,1)  primary key,
pname		varchar(100) not null,
descp		varchar(100) null,
price		int not null,
create_date date default getdate(),
status		int   check (status in (1,0))
)

insert into product(pname,price)
values('dove',45)


insert into product(pname,price,status)
values('iphone',450,1)

select * from product




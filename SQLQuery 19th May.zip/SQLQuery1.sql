use hrms

select * from j_employee
select * into emp2 from j_employee

--return common rows
select * from j_employee
intersect
select * from emp2

--return all rows from fist table which is not match in 2nd table
select * from j_employee
except 
select * from emp2


begin tran 

delete from emp2 

select * from emp2 


--rollback 
commit 

--shwo distinct rows 
select distinct * from emp2



--
select gender,count(*) as no_of_rows,sum(eid) as sum_of_eid 
from j_employee
group by gender 



select gender,count(*) as no_of_rows,sum(eid) as sum_of_eid 
from j_employee
group by gender 
having count(*)>4



--
create proc test_proc
(
@a int  ,--default in 
@b int out
)
as
begin
		set @b = @a 
		select @b 
end


declare @b int 
execute test_proc 11,@b
select @b 


